# Fight On 1.0 — Android build project

Fight On is an offline-first app using HTML, CSS, JavaScript, IndexedDB, Vite and Capacitor.

## Build an Android APK without Android Studio on your phone

This project includes a GitHub Actions workflow that builds a debug APK in GitHub's cloud.

1. Extract this ZIP.
2. Upload the complete `fight_on_v1` folder contents to a new GitHub repository (the `.github` folder must also be uploaded).
3. Open the repository on GitHub and select **Actions**.
4. Select **Build Fight On Android APK**.
5. Press **Run workflow** and wait for the build to finish.
6. Open the completed workflow run, find **Artifacts**, and download `Fight-On-debug-APK`.
7. Extract the downloaded artifact ZIP to get `app-debug.apk`, then install it on Android. Android may ask you to allow installation from that source.

The workflow builds a debug APK for testing. A release APK for public distribution should be signed with a private keystore; do not share the keystore or passwords.

## Local development (computer)

Requirements: Node.js 20+, Java 17, Android SDK.

```bash
npm install
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

APK output: `android/app/build/outputs/apk/debug/app-debug.apk`.

## Notifications

The app uses Capacitor Local Notifications. Notifications are Android local scheduled reminders, not remote push messages. After installing the APK, grant notification permission in Android and enable the reminder in Fight On settings. Android battery restrictions and device settings may affect exact delivery time.

## Important

Opening `index.html` directly from a file manager is not a supported way to run this Capacitor/Vite project. Use the built APK or run the Vite development server.
